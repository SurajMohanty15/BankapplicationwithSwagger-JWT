//package com.fis.bankapplication.dao;
//
//import java.util.List;
//
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.persistence.TypedQuery;
//import javax.transaction.Transactional;
//
//import org.springframework.stereotype.Repository;
//
//import com.fis.bankapplication.exceptions.AccountNotFound;
//import com.fis.bankapplication.model.Account;
//import com.fis.bankapplication.model.Customer;
//
//@Repository
//@Transactional
//public class AccountDaoImpl implements AccountDao {
//
//	@PersistenceContext
//	private EntityManager entityManager;
//	
//	@Override
//	public String addAccount(Account account) {
//		entityManager.persist(account);
//		return "Account get added to the database.";
//	}
//
//	@Override
//	public Account getAccountByAccountId(int accountId) throws AccountNotFound {
//		if(entityManager.find(Account.class, accountId)!=null) {
//		return entityManager.createQuery("Select a FROM Account a JOIN FETCH a.customer WHERE a.id = :accountId",
//				Account.class).setParameter("accountId", accountId).getSingleResult();
//	}else {
//		throw new AccountNotFound("Invalid Account Number");
//	}
//	}
//
//	@Override
//	public String updateAccount(int accoundId,double amount) {
//		Account account = entityManager.find(Account.class, accoundId);
//		account.setBalance(amount);
//		entityManager.merge(account);
//		return "Updated account";
//	}
//
//	@Override
//	public void deleteAccount(int accountId) {
//		Account account = entityManager.find(Account.class, accountId);
//		if(account != null) {
//			entityManager.remove(account);
//		}
//	}
//
//	@Override
//	public List<Account> getAllAccountsByBalanceRange(double minBal, double maxBal) {
//		TypedQuery<Account> query = entityManager.createQuery(
//				"SELECT a FROM Account a WHERE a.balance >= :minBal AND a.balance <= :maxBal",Account.class);
//				query.setParameter("minBal",minBal);
//				query.setParameter("maxBal",maxBal);
//				return query.getResultList();
//	}
//
//	@Override
//	public List<Account> getAllAccounts() {
//		return entityManager.createQuery("Select a from Account a",Account.class).getResultList();
//		
//	}
//
//}
