package com.fis.bankapplication.service;
import java.util.List;


import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.service.CustomerService;


@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{
	
	@Autowired
	private CustomerDao customerDAO;
	
	//to create Customer
	@Override
	public String addUser(Customer customer) {
		customerDAO.save(customer);
		return "Customer added to the database";
	}

	//to update Customer
	@Override
	public void updateCustomer(int customerId,String name,String address) throws CustomerNotFound {
			customerDAO.updateCustomer(customerId, name, address);
	}

	//to delete customer
	@Override
	public String deleteUser(int customerId) {
		customerDAO.deleteById(customerId);
		return "Customer deleted";
	}

	// to get customer details by customer id
	@Override
	public Optional<Customer> getUser(int customerId) throws CustomerNotFound {
		Optional<Customer> cust = customerDAO.findById(customerId);
		return cust;
	}
	
	//to get all customer 
	@Override
	public List<Customer> getAllCustomer() {
		return customerDAO.findAll();
	}
}
