package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.query.Param;

import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Customer;

public interface CustomerService {
	public abstract String addUser(Customer customer);
	public abstract void updateCustomer(@Param("accountId") int accountId,@Param("newName") String name,@Param("newAddress") String address) throws CustomerNotFound;
//	public abstract String updateUser(int customerId,String name,String address) throws CustomerNotFound;
	public abstract String deleteUser(int customerId);
	public abstract Optional<Customer> getUser(int customerId) throws CustomerNotFound;
	public abstract List<Customer> getAllCustomer();
}
