package com.fis.bankapplication.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Account;
//import com.fis.bankapplication.service.AccountService;
import com.fis.bankapplication.service.AccountServiceImpl;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;



@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	private AccountServiceImpl accountService;
	
	@PostMapping
	public String addAccount(@RequestBody Account account) {
			accountService.addAccount(account);
			return "Account added to the database";
	}
	
	@GetMapping("/getAccount/{accountId}")
	public Optional<Account> getAccountDetails(@PathVariable("accountId") int accountId) throws AccountNotFound {
		Optional<Account> account = accountService.getAccountByAccountId(accountId);
		return account;
	}
	
	@DeleteMapping("/deleteAccount/{accountId}")
	public void deleteAccountDetails(@PathVariable("accountId") int accountId) {
		accountService.deleteAccount(accountId);
	}
	
	@PutMapping("/updateAccountBalance/{accountId}")
	public String updateAccountDetails(
			@PathVariable("accountId") int accountId,
			@RequestParam double newBalance
			) {
		accountService.updateAccount(accountId, newBalance);
		return "Account amount Updated with id:" + accountId;
	}
	
	
	@GetMapping("/getAllAccountsByRange/{minBal}/{maxBal}")
	public List<Account> getProducts(@PathVariable("minBal") double minBal, @PathVariable("maxBal") double maxBal) {
		return accountService.getAllAccountsByBalanceRange(minBal, maxBal);
	}
//	
	@GetMapping("/getAllAccounts")
	public List<Account> getProducts() {
		return accountService.getAllAccounts();
	}
}
