package com.fis.bankapplication.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.model.Account;

public interface AccountDao extends JpaRepository<Account,Integer> {
	
	//public abstract String getAccountByAccountId(int accountId) throws AccountNotFound;
	
	@Query("UPDATE Account ba SET ba.balance = :newBalance where ba.id = :accountId")
	@Modifying
	public abstract void updateAccount(@Param("accountId") int accountId, @Param("newBalance") double amount);
	
	@Query("SELECT a FROM Account a WHERE a.balance >= :minBal AND a.balance <= :maxBal")
	@Modifying
	public abstract List<Account> getAllAccountsByBalanceRange (double minBal,double maxBal);

}
