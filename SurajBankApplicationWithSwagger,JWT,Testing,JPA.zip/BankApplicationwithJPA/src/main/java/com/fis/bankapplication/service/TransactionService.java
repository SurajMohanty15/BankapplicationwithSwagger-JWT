package com.fis.bankapplication.service;

import java.util.List;

import com.fis.bankapplication.exceptions.NotEnoughBalance;
import com.fis.bankapplication.model.Transaction;

public interface TransactionService {
	public abstract void deposit(int accountId,double amount);
	public abstract void withdraw(int accountId,double amount) throws NotEnoughBalance;
	public abstract void fundTransfer(int fromAccountId,int toAccountId,double amount) throws NotEnoughBalance;
	public abstract List<Transaction> getAllTranscation();
//	public abstract List<Transaction> getAllTranscationByAccountId(int accountId);
}
