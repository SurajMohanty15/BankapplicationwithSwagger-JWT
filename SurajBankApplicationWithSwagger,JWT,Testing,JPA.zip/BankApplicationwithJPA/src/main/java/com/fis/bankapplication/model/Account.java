package com.fis.bankapplication.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Min;
import javax.validation.constraints.Past;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Account {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int accountId;
	private String name;
	private String typeOfAccount;
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	@Past(message="Date of Opening could not be present or future date ")
	private Date dateOfOpening;
	private String ifsc;
	@Min(1000)
	private double balance;
	
	@ManyToOne
	@JoinColumn(name = "custId")
	private Customer customer;
	
	public Account() {
		
	}

	public Account(int accountId, String name, String typeOfAccount,Date dateOfOpening,  String ifsc, double balance,
			Customer customer) {
		super();
		this.accountId = accountId;
		this.name = name;
		this.typeOfAccount = typeOfAccount;
		this.dateOfOpening = dateOfOpening;
		this.ifsc = ifsc;
		this.balance = balance;
		this.customer = customer;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTypeOfAccount() {
		return typeOfAccount;
	}

	public void setTypeOfAccount(String typeOfAccount) {
		this.typeOfAccount = typeOfAccount;
	}
	
	public Date getDateOfOpening() {
		return new Date();
	}

	public void setDateOfOpening(Date dateOfOpening) {
		this.dateOfOpening = dateOfOpening;
	}
	
	public String getIFSC() {
		return ifsc;
	}

	public void setIFSC(String ifsc) {
		this.ifsc = ifsc;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
}
