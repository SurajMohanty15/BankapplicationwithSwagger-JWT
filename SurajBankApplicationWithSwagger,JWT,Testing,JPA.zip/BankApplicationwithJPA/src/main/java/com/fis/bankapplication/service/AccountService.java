package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;

import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Account;

public interface AccountService {
	public abstract String addAccount(Account account);
	public abstract Optional<Account> getAccountByAccountId(int accountId) throws AccountNotFound;
	public abstract void updateAccount(int accountId,double amount);
	public abstract void deleteAccount(int accountId);
	public abstract List<Account> getAllAccountsByBalanceRange (double minBal,double maxBal);
	public abstract List<Account> getAllAccounts();
}
