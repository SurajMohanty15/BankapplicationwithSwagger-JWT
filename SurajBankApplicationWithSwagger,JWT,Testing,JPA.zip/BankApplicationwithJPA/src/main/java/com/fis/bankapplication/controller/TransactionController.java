package com.fis.bankapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.bankapplication.exceptions.NotEnoughBalance;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.TransactionService;



@RestController
@RequestMapping("/transactions")
public class TransactionController {
	
	@Autowired
	private TransactionService transactionService;
	
	@PostMapping("/deposit/{accountId}")
	public String depositAmount(
			@PathVariable("accountId") int accountId,
			@RequestParam double amount
			) {
		transactionService.deposit(accountId, amount);
		return "Transaction Deposite Done";
	}
	
	@PostMapping("/withdraw/{accountId}")
	public String withdrawAmount(
			@PathVariable("accountId") int accountId,
			@RequestParam double amount
			) throws NotEnoughBalance {
		transactionService.withdraw(accountId, amount);
		return "Transaction Withdraw Done";
	}
	
	@PostMapping("/fundtransfer/{fromAccount}/{toAccount}")
	public String fundTransferAmount(
			@PathVariable("fromAccount") int fromAccount,
			@PathVariable("toAccount") int toAccount,
			@RequestParam double amount
			) {
		try {
			transactionService.fundTransfer(fromAccount, toAccount, amount);
		} catch (NotEnoughBalance e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Transaction Fund Transfer Done";
	}
	
	@GetMapping("/getAllTransaction")
	public List<Transaction> getAllTransaction(){
		return transactionService.getAllTranscation();
	}
	
//	@GetMapping("/getAllTransactionByAccountId/{fromAccount}")
//	public List<Transaction> getAllTransactionByAccountId(
//			@PathVariable("fromAccount") int fromAccount
//			){
//		return transactionService.getAllTranscationByAccountId(fromAccount);
//	}
}
