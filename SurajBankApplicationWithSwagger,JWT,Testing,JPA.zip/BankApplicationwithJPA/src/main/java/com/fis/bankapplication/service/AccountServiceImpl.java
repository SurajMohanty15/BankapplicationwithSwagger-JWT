package com.fis.bankapplication.service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.dao.CustomerDao;
import com.fis.bankapplication.exceptions.AccountNotFound;
import com.fis.bankapplication.exceptions.CustomerNotFound;
import com.fis.bankapplication.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService{

	@Autowired
	private AccountDao accountDAO;
	
	//to create Account
	@Override
	public  String addAccount(Account account) {
		accountDAO.save(account);
		return "Account save to Database";
	}

	//to get Account details by accountId
	@Override
	public Optional<Account> getAccountByAccountId(int accountId){
		Optional<Account> accnt = accountDAO.findById(accountId);
			return accnt;
	}

	//to update the Account details
	@Override
	public void updateAccount(int accountId,double amount) {
			accountDAO.updateAccount(accountId,amount);
			
	}

	//to delete Account 
	@Override
	public void deleteAccount(int accountId) {
		accountDAO.deleteById(accountId);
	}

	//to get Account details of by balance range
	@Override
	public List<Account> getAllAccountsByBalanceRange(double minBal, double maxBal) {
		return accountDAO.getAllAccountsByBalanceRange(minBal,maxBal);
	}
	
	//to get All Accounts details
	public List<Account> getAllAccounts(){
		return accountDAO.findAll();
	}

}
